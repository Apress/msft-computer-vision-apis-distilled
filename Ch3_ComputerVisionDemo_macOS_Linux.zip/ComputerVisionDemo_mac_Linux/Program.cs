﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using Newtonsoft.Json.Linq;
using System.Net;
using System.IO;

namespace ComputerVisionDemo_mac_Linux
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }

                async static Task AnalyzeImageAsync()
        {
            var client = new HttpClient();

            // Request parameters. A third optional parameter is "details".
            string requestParameters = "visualFeatures=Categories,Description,Color,Faces,Adult";

            // Request headers
            client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "YOUR-KEY-GOES-HERE");

            string uri = 
                "https://westus.api.cognitive.microsoft.com/vision/v1.0/analyze?" 
                + requestParameters;

            HttpResponseMessage response;

            JObject imageUrl = new JObject(
                               new JProperty("url",
                               "http://community.visual-basic.it/images/community_visual-basic_it/Alessandro/184/o_AleDelSole.png"));


            // Request body
            using (var content = 
                new StringContent(imageUrl.ToString(), Encoding.UTF8, "application/json"))
            {
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                response = await client.PostAsync(uri, content);

                if(response.StatusCode == HttpStatusCode.OK)
                {
                    string jsonResponse = await response.Content.ReadAsStringAsync();

                    var parsedJson = JObject.Parse(jsonResponse);
                    Console.WriteLine(parsedJson.ToString());
                }

            }

            Console.ReadLine();
        }

        async static Task DescribeImageAsync()
        {
            var client = new HttpClient();

            // Return two natural-language sentences
            string requestParameters = "maxCandidates=2";

            // Add the subscription key to the header
            client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "YOUR-KEY-GOES-HERE");

            // Define the API endpoint
            string uri = "https://westus.api.cognitive.microsoft.com/vision/v1.0/describe?" + requestParameters;

            HttpResponseMessage response;

            // Construct a well-formed JSON key/value pair that
            // represents the image URL
            JObject imageUrl = new JObject(
                               new JProperty("url", 
                               "http://community.visual-basic.it/images/community_visual-basic_it/Alessandro/184/o_SeasideLandscape.jpg"));

            // You pass the JSON object above as the request body
            using (var content =
                new StringContent(imageUrl.ToString(), Encoding.UTF8, "application/json"))
            {
                // Add headers
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                // Call the endpoint
                response = await client.PostAsync(uri, content);

                // If successful,
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    // Read the resulting HTTP content as a string
                    string jsonResponse = await response.Content.ReadAsStringAsync();

                    // Generate fully-indented JSON markup from the original response
                    var parsedJson = JObject.Parse(jsonResponse);

                    string description = parsedJson["description"]["captions"][1]["text"].ToString();


                    Console.WriteLine(parsedJson.ToString());
                }

            }

            Console.ReadLine();
        }
        async static Task GenerateThumbnailAsync()
        {
            var client = new HttpClient();

            // Return two natural-language sentences
            string requestParameters = "width=320&height=240";

            // Add the subscription key to the header
            client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "YOUR-KEY-GOES-HERE");

            // Define the API endpoint
            string uri = "https://westus.api.cognitive.microsoft.com/vision/v1.0/GenerateThumbnail?" + requestParameters;

            HttpResponseMessage response;

            // Construct a well-formed JSON key/value pair that
            // represents the image URL
            JObject imageUrl = new JObject(
                               new JProperty("url",
                               "http://community.visual-basic.it/images/community_visual-basic_it/Alessandro/184/o_SeasideLandscape.jpg"));

            // You pass the JSON object above as the request body
            using (var content =
                new StringContent(imageUrl.ToString(), Encoding.UTF8, "application/json"))
            {
                // Add headers
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                // Call the endpoint
                response = await client.PostAsync(uri, content);

                // If successful,
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    // Get the thumbnail as a MemoryStream
                    var binaryResponse = await response.Content.ReadAsStreamAsync();
                }

            }

            Console.ReadLine();
        }
        async static Task TagImageAsync()
        {
            var client = new HttpClient();

            // Add the subscription key to the header
            client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "YOUR-KEY-GOES-HERE");

            // Define the API endpoint
            string uri = "https://westus.api.cognitive.microsoft.com/vision/v1.0/tag";

            HttpResponseMessage response;

            // Construct a well-formed JSON key/value pair that
            // represents the image URL
            JObject imageUrl = new JObject(
                               new JProperty("url",
                               "http://community.visual-basic.it/images/community_visual-basic_it/Alessandro/184/o_SeasideLandscape.jpg"));

            // You pass the JSON object above as the request body
            using (var content =
                new StringContent(imageUrl.ToString(), Encoding.UTF8, "application/json"))
            {
                // Add headers
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                // Call the endpoint
                response = await client.PostAsync(uri, content);

                // If successful,
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    // Read the resulting HTTP content as a string
                    string jsonResponse = await response.Content.ReadAsStringAsync();

                    // Generate fully-indented JSON markup from the original response
                    var parsedJson = JObject.Parse(jsonResponse);
                    Console.WriteLine(parsedJson.ToString());
                }

            }

            Console.ReadLine();
        }

        async static Task RecognizeTextAsync()
        {
            var client = new HttpClient();

            // Add the subscription key to the header
            client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "YOUR-KEY-GOES-HERE");

            // Define the API endpoint
            string uri = "https://westus.api.cognitive.microsoft.com/vision/v1.0/ocr";

            HttpResponseMessage response;

            // Construct a well-formed JSON key/value pair that
            // represents the image URL
            JObject imageUrl = new JObject(
                               new JProperty("url",
                               "http://community.visual-basic.it/images/community_visual-basic_it/Alessandro/184/o_OcrSample.jpg"));

            // You pass the JSON object above as the request body
            using (var content =
                new StringContent(imageUrl.ToString(), Encoding.UTF8, "application/json"))
            {
                // Add headers
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                // Call the endpoint
                response = await client.PostAsync(uri, content);

                // If successful,
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    // Read the resulting HTTP content as a string
                    string jsonResponse = await response.Content.ReadAsStringAsync();

                    // Generate fully-indented JSON markup from the original response
                    var parsedJson = JObject.Parse(jsonResponse);
                    Console.WriteLine(parsedJson.ToString());
                }

            }

            Console.ReadLine();
        }

        async static Task ListModelsAsync()
        {
            var client = new HttpClient();

            // Add the subscription key to the header
            client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "YOUR-KEY-GOES-HERE");

            // Define the API endpoint
            string uri = "https://westus.api.cognitive.microsoft.com/vision/v1.0/models";

            HttpResponseMessage response;

            // Call the endpoint
            response = await client.GetAsync(uri);

            // If successful,
            if (response.StatusCode == HttpStatusCode.OK)
            {
               // Read the resulting HTTP content as a string
               string jsonResponse = await response.Content.ReadAsStringAsync();

               // Generate fully-indented JSON markup from the original response
               var parsedJson = JObject.Parse(jsonResponse);
               Console.WriteLine(parsedJson.ToString());
            }

            Console.ReadLine();
        }

        async static Task RecognizeCelebrityAsync()
        {
            var client = new HttpClient();

            // Add the subscription key to the header
            client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "YOUR-KEY-GOES-HERE");

            // Define the API endpoint
            string uri = "https://westus.api.cognitive.microsoft.com/vision/v1.0/models/celebrities/analyze";

            HttpResponseMessage response;

            // Construct a well-formed JSON key/value pair that
            // represents the image URL
            JObject imageUrl = new JObject(
                               new JProperty("url",
                               "https://ichef.bbci.co.uk/images/ic/960x540/p01bqmwg.jpg"));

            // You pass the JSON object above as the request body
            using (var content =
                new StringContent(imageUrl.ToString(), Encoding.UTF8, "application/json"))
            {
                // Add headers
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                // Call the endpoint
                response = await client.PostAsync(uri, content);

                // If successful,
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    // Read the resulting HTTP content as a string
                    string jsonResponse = await response.Content.ReadAsStringAsync();

                    // Generate fully-indented JSON markup from the original response
                    var parsedJson = JObject.Parse(jsonResponse);
                    Console.WriteLine(parsedJson.ToString());
                }

            }

            Console.ReadLine();
        }
    }
}
