﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebComputerVision.Models;
using System.Net.Http;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Http;
using System.IO;
using Newtonsoft.Json.Linq;

namespace WebComputerVision.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult Vision()
        {
            ViewData["Message"] = "Picture analysis";

            return View();
        }


        private string BytesToSrcString(byte[] bytes) => "data:image/jpg;base64," + Convert.ToBase64String(bytes);

        // IFormFile represents a file that can be sent 
        // with HTTP requests
        private string FileToImgSrcString(IFormFile file)
        {
            byte[] fileBytes;
            using (var stream = file.OpenReadStream())
            {

                using (var memoryStream = new MemoryStream())
                {
                    stream.CopyTo(memoryStream);
                    fileBytes = memoryStream.ToArray();
                }
            }
            return BytesToSrcString(fileBytes);
        }

        private const string apiKey = "YOUR-KEY-GOES-HERE";

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Vision(IFormFile file)
        {
            //put the original file in the view data 
            ViewData["originalImage"] = FileToImgSrcString(file);
            string result = null;

            using (var httpClient = new HttpClient())
            {
                // Request parameters
                string baseUri = "https://westus.api.cognitive.microsoft.com/vision/v1.0/describe";

                //setup HttpClient
                httpClient.BaseAddress = new Uri(baseUri);
                httpClient.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", apiKey);

                //setup data object
                HttpContent content = new StreamContent(file.OpenReadStream());
                content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/octet-stream");

                //make request
                var response = await httpClient.PostAsync(baseUri, content);

                // get the string for the JSON response
                string jsonResponse = await response.Content.ReadAsStringAsync();

                // You can replace the following code with customized or
                // more precise JSON deserialization
                var jresult = JObject.Parse(jsonResponse);

                result = jresult["description"]["captions"][0]["text"].ToString();
            }

            ViewData["result"] = result;
            return View();
        }
    }
}
