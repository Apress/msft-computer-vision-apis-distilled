﻿using Microsoft.ProjectOxford.Vision;
using Xamarin.Forms;

namespace ComputerVisionDemo
{
    public partial class App : Application
    {
        internal static VisionServiceClient visionClient;
        public App()
        {
            InitializeComponent();

            visionClient = new VisionServiceClient("60fd687303304c66846b0f89f0d6a764", 
                "https://westeurope.api.cognitive.microsoft.com/vision/v1.0");
            MainPage = new ComputerVisionDemo.MainPage();
        }

        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            // Handle when your app resumes
        }
    }
}
